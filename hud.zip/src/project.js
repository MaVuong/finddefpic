window.__require = function t(e, r, c) {
function n(o, i) {
if (!r[o]) {
if (!e[o]) {
var a = o.split("/");
a = a[a.length - 1];
if (!e[a]) {
var u = "function" == typeof __require && __require;
if (!i && u) return u(a, !0);
if (s) return s(a, !0);
throw new Error("Cannot find module '" + o + "'");
}
o = a;
}
var f = r[o] = {
exports: {}
};
e[o][0].call(f.exports, function(t) {
return n(e[o][1][t] || t);
}, f, f.exports, t, e, r, c);
}
return r[o].exports;
}
for (var s = "function" == typeof __require && __require, o = 0; o < c.length; o++) n(c[o]);
return n;
}({
newscctrl: [ function(t, e, r) {
"use strict";
cc._RF.push(e, "90ee0MkfjFDdqm0ja+Oh6jc", "newscctrl");
cc.Class({
extends: cc.Component,
properties: {
sptest: cc.Node
},
onLoad: function() {
var t = jsb.fileUtils.getSearchPaths();
Array.prototype.unshift.apply(t, [ "E:/TMP/hud/" ]);
cc.sys.localStorage.setItem("HotUpdateSearchPaths", JSON.stringify(t));
jsb.fileUtils.setSearchPaths(t);
cc.log("----searchPaths=" + jsb.fileUtils.getSearchPaths());
this._storagePath = "E:/TMP/hud";
},
start: function() {},
runActionTest: function() {
this.sptest.runAction(cc.moveTo(2, cc.v2(500, 300)));
}
});
cc._RF.pop();
}, {} ]
}, {}, [ "newscctrl" ]);